package com.pickmyorder.asharani;

public interface Nav_Drawer {

    public void drawer_nav();

}
