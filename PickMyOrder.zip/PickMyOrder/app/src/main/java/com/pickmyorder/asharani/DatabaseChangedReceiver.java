package com.pickmyorder.asharani;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class DatabaseChangedReceiver extends BroadcastReceiver {
    public static String ACTION_DATABASE_CHANGED = "com.example.scorpsoft.DATABASE_CHANGED";

    @Override
    public void onReceive(Context context, Intent intent) {

    }
}