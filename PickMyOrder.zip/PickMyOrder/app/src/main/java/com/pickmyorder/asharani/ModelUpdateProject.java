package com.pickmyorder.asharani;

public class ModelUpdateProject {

    String eng_id;

    public String getEng_id() {
        return eng_id;
    }

    public void setEng_id(String eng_id) {
        this.eng_id = eng_id;
    }

    public String getEng_name() {
        return eng_name;
    }

    public void setEng_name(String eng_name) {
        this.eng_name = eng_name;
    }

    String eng_name;
}
