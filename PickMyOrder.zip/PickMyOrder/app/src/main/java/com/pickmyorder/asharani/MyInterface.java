package com.pickmyorder.asharani;

public interface MyInterface {

    public void foo();

    public void updateCart();
}
