package com.pickmyorder.asharani;

public class Model_Home_Sub_Category {


    String SuperSubImage;
    String SuperSubtext;
    String subcat;


    public Model_Home_Sub_Category() {

    }

    public String getSuperSubImage() {
        return SuperSubImage;
    }

    public void setSuperSubImage(String superSubImage) {
        SuperSubImage = superSubImage;
    }

    public String getSuperSubtext() {
        return SuperSubtext;
    }

    public void setSuperSubtext(String superSubtext) {
        SuperSubtext = superSubtext;
    }

    public String getSubcat() {
        return subcat;
    }
    public void setSubcat(String subcat) {
        this.subcat = subcat;
    }

}
