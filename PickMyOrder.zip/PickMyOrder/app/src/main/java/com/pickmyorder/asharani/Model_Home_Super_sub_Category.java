package com.pickmyorder.asharani;

public class Model_Home_Super_sub_Category {

    String SuperImage;
    String Supertext;
    String subcat;

    public Model_Home_Super_sub_Category() {

    }

    public String getSuperImage() {
        return SuperImage;
    }

    public void setSuperImage(String superImage) {
        SuperImage = superImage;
    }

    public String getSupertext() {
        return Supertext;
    }

    public void setSupertext(String supertext) {
        Supertext = supertext;
    }

    public String getSubcat() {
        return subcat;
    }

    public void setSubcat(String subcat) {
        this.subcat = subcat;
    }

}
